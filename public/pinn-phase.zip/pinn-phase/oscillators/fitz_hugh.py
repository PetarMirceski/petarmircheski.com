from collections.abc import Callable

import numpy as np


def fitz_hugh_model(
    a_parameter: float,
    b_parameter: float,
    e_parameter: float,
    excitation: float,
) -> Callable[[np.ndarray], np.ndarray]:
    def fitz_model(input_state: np.ndarray) -> np.ndarray:
        u = input_state[0]
        v = input_state[1]
        v_3 = v * v * v

        du_vector = e_parameter * (v + a_parameter - b_parameter * u)
        dv_vector = v - v_3 / 3 - u + excitation
        return np.array([du_vector, dv_vector])

    return fitz_model


def fitz_hugh_jacobian_model(
    a_parameter: float,
    b_parameter: float,
    e_parameter: float,
    excitation: float,
) -> Callable[[np.ndarray], np.ndarray]:
    def fitz_jacobian(state: np.ndarray) -> np.ndarray:
        v = state[1]
        v_2 = v * v
        return np.array([[-b_parameter * e_parameter, e_parameter], [-1, 1 - v_2]])

    return fitz_jacobian


def fitz_hugh_perturbated_model(
    a_parameter: float,
    b_parameter: float,
    e_parameter: float,
    excitation: float,
) -> Callable[[np.ndarray, np.ndarray], np.ndarray]:
    fitz_model = fitz_hugh_model(a_parameter, b_parameter, e_parameter, excitation)

    def perturbated_fitz_hugh(
        x_state: np.ndarray, perturbation: np.ndarray
    ) -> np.ndarray:
        x_dot: np.ndarray = fitz_model(x_state) + perturbation
        return x_dot

    return perturbated_fitz_hugh
