from collections.abc import Callable

import numpy as np


def stuart_landau(alpha: float, beta: float) -> Callable[[np.ndarray], np.ndarray]:
    def rhs(x_state: np.ndarray) -> np.ndarray:
        x = x_state[0]
        y = x_state[1]

        dx = x - alpha * y - (x - beta * y) * (x**2 + y**2)
        dy = alpha * x + y - (beta * x + y) * (x**2 + y**2)
        return np.array([dx, dy])

    return rhs


def stuart_landau_jacobian(
    alpha: float, beta: float
) -> Callable[[np.ndarray], np.ndarray]:
    def jac(state: np.ndarray) -> np.ndarray:
        x = state[0]
        y = state[1]
        return np.array(
            [
                [
                    -(x**2) - 2 * x * (-beta * y + x) - y**2 + 1,
                    -alpha + beta * (x**2 + y**2) - 2 * y * (-beta * y + x),
                ],
                [
                    alpha - beta * (x**2 + y**2) - 2 * x * (beta * x + y),
                    -(x**2) - y**2 - 2 * y * (beta * x + y) + 1,
                ],
            ]
        )

    return jac


def perturbated_stuart_landau(
    alpha: float, beta: float
) -> Callable[[np.ndarray, np.ndarray], np.ndarray]:
    model = stuart_landau(alpha, beta)

    def rhs(x_state: np.ndarray, perturbation: np.ndarray) -> np.ndarray:
        return model(x_state) + perturbation

    return rhs
