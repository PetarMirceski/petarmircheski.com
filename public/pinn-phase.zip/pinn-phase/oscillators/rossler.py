from collections.abc import Callable

import numpy as np


def rossler(a: float, b: float, c: float) -> Callable[[np.ndarray], np.ndarray]:
    def rhs(x_state: np.ndarray) -> np.ndarray:
        x = x_state[0]
        y = x_state[1]
        z = x_state[2]
        dx = -y - z
        dy = x + a * y
        dz = b + z * (x - c)
        return np.array([dx, dy, dz])

    return rhs


def rossler_jacobian(
    a: float, b: float, c: float
) -> Callable[[np.ndarray], np.ndarray]:
    def jac(state: np.ndarray) -> np.ndarray:
        x = state[0]
        z = state[2]
        return np.array(
            [
                [0.0, -1.0, -1.0],
                [1.0, a, 0.0],
                [z, 0.0, x - c],
            ]
        )

    return jac


def perturbated_rossler(
    a: float, b: float, c: float
) -> Callable[[np.ndarray, np.ndarray], np.ndarray]:
    model = rossler(a, b, c)

    def rhs(x_state: np.ndarray, perturbation: np.ndarray) -> np.ndarray:
        return model(x_state) + perturbation

    return rhs
