from collections.abc import Callable
from typing import Literal

import numpy as np
import numpy.typing as npt
from joblib import Parallel, delayed
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from scipy.optimize import minimize_scalar
from tqdm import tqdm

type VectorField = Callable[[np.ndarray], np.ndarray]
type OdeSolver = Literal["RK45", "DOP853", "BDF", "LSODA", "Radau"]


class PhaseSolver:
    DEFAULT_RTOL: float = 1e-9
    DEFAULT_ATOL: float = 1e-12

    def __init__(
        self,
        system: VectorField,
        period: float,
        time_vector: np.ndarray,
        limit_cycle: np.ndarray,
        psf: np.ndarray,
        rtol: float = DEFAULT_RTOL,
        atol: float = DEFAULT_ATOL,
        ode_method: OdeSolver = "RK45",
        n_jobs: int = -1,
    ) -> None:
        self.system = system
        self.period = period
        self.omega = 2 * np.pi / period
        self.rtol = rtol
        self.atol = atol
        self.method = ode_method
        self.n_jobs = n_jobs

        self._time_vector = time_vector
        self._limit_cycle = limit_cycle
        self._psf = psf

        self._lc_spline = CubicSpline(
            time_vector, limit_cycle, bc_type="periodic", extrapolate="periodic"
        )
        self._psf_spline = CubicSpline(
            time_vector, psf, bc_type="periodic", extrapolate="periodic"
        )

    def _nearest_on_lc(
        self,
        relaxed: np.ndarray,
    ) -> tuple[float, np.ndarray]:
        dists = np.linalg.norm(self._limit_cycle - relaxed, axis=1)
        t_coarse = float(self._time_vector[np.argmin(dists)])

        dt_grid = float(self._time_vector[1] - self._time_vector[0])
        lo = max(0.0, t_coarse - 2 * dt_grid)
        hi = min(self.period, t_coarse + 2 * dt_grid)

        result = minimize_scalar(
            lambda t: float(np.sum((self._lc_spline(t) - relaxed) ** 2)),
            bounds=(lo, hi),
            method="bounded",
        )
        t_star = float(result.x) % self.period
        return t_star, relaxed - self._lc_spline(t_star)

    def phase_of_point(
        self,
        point: np.ndarray,
        num_periods: int = 7,
    ) -> tuple[float, np.ndarray]:
        relaxed = self.relax_point(point, num_periods)
        t_star, _ = self._nearest_on_lc(relaxed)
        theta = (t_star / self.period) * 2 * np.pi % (2 * np.pi)
        return theta, point - self._lc_spline(t_star)

    def phase_of_batch(
        self,
        points: np.ndarray,
        num_periods: int = 7,
        show_progress: bool = True,
    ) -> tuple[npt.NDArray[np.float64], np.ndarray]:
        points_len = points.shape[0]

        results: list[tuple[float, np.ndarray]] = list(
            Parallel(n_jobs=self.n_jobs)(
                delayed(self.phase_of_point)(points[i], num_periods)
                for i in tqdm(range(points_len), disable=not show_progress, leave=False)
            )
        )

        thetas = np.array([r[0] for r in results])
        deviations = np.array([r[1] for r in results])
        return thetas, deviations

    def relax_point(self, point: np.ndarray, num_periods: int = 7) -> np.ndarray:
        sol = solve_ivp(
            lambda _, y: self.system(y),
            (0, self.period * num_periods),
            point,
            method=self.method,
            rtol=self.rtol,
            atol=self.atol,
        )
        return sol.y[:, -1]

    def relax_batch(
        self,
        points: np.ndarray,
        num_periods: int = 7,
        show_progress: bool = True,
    ) -> np.ndarray:
        relaxed: list[np.ndarray] = list(
            Parallel(n_jobs=self.n_jobs)(
                delayed(self.relax_point)(points[i], num_periods)
                for i in tqdm(
                    range(points.shape[0]), disable=not show_progress, leave=False
                )
            )
        )
        return np.array(relaxed)
