from collections.abc import Callable

import torch

from solvers.phase_net import PhaseNet


def loss_pde(
    net: PhaseNet,
    pts: torch.Tensor,
    F_func: Callable[[torch.Tensor], torch.Tensor],
    omega: float,
    normalize_by_speed: bool = False,
) -> torch.Tensor:
    r"""
    PDE residual loss.

    For u = $\cos \Theta$ and $v = \sin \Theta$ the loss $F \nabla \Theta = \omega$ becomes:
        $F \nabla u + \omega v = 0 $
        $F \nabla v - \omega u = 0 $

    normalize_by_speed: if True, divide each point's squared residual by $|F(x)|^2$.
        This prevents fast regions (large $|F|$) and huge gradients from dominating the loss, which is
        important for slow fast systems systems (eg. Neuron spiking systems FHN or scuh).
    """
    pts = pts.detach().requires_grad_(True)
    out = net(pts)
    u, v = out[:, 0], out[:, 1]

    grad_u = torch.autograd.grad(u.sum(), pts, create_graph=True)[0]
    grad_v = torch.autograd.grad(v.sum(), pts, create_graph=True)[0]

    F = F_func(pts)
    Fu = (grad_u * F).sum(dim=1)
    Fv = (grad_v * F).sum(dim=1)

    res_u = Fu + omega * v  # is zero
    res_v = Fv - omega * u  # is zero

    if (
        normalize_by_speed
    ):  # prevent fast regions from dominating the loss sometimes imporant not used
        F_sq = (F**2).sum(dim=1).clamp(min=1e-8)
        return ((res_u**2 + res_v**2) / F_sq).mean()
    return (res_u**2 + res_v**2).mean()


def loss_bc(
    net: PhaseNet,
    lc_pts: torch.Tensor,
    cos_target: torch.Tensor,
    sin_target: torch.Tensor,
) -> torch.Tensor:
    r"""Boundary condition on the limit cycle: $\Theta(x_0(t) = \omega t$. On the limit cycle the phase linearly increases with $\omega t$."""
    out = net(lc_pts)
    return ((out[:, 0] - cos_target) ** 2 + (out[:, 1] - sin_target) ** 2).mean()


def loss_norm(net: PhaseNet, pts: torch.Tensor) -> torch.Tensor:
    r"""Soft unit-circle constraint: $\cos^2 \Theta + \sin^2 \Theta = 1.
    (This is legacy and not needed since the PDE loss already kinda encourages this, but it can help with training (maybe not checked not included in manucsipt) in some cases.)"""
    out = net(pts)
    return ((out[:, 0] ** 2 + out[:, 1] ** 2 - 1.0) ** 2).mean()


def loss_adjoint(
    net: PhaseNet,
    pts: torch.Tensor,
    F_func: Callable[[torch.Tensor], torch.Tensor],
    omega: float,
) -> torch.Tensor:
    r"""Adjoint loss.

    Differentiating the PDE residuals from loss_pde with respect to $x$ gives:
            $\nabla(F \nabla u + \omega v) = 0$
            $\nabla(F \nabla v - \omega u) = 0$
    This is fully consistent with loss_pde.
    """
    pts = pts.detach().requires_grad_(True)
    out = net(pts)  # [N, 2]
    u, v = out[:, 0], out[:, 1]

    grad_u = torch.autograd.grad(u.sum(), pts, create_graph=True)[0]  # [N, dim]
    grad_v = torch.autograd.grad(v.sum(), pts, create_graph=True)[0]  # [N, dim]

    F = F_func(pts)  # [N, dim]
    res_u = (grad_u * F).sum(dim=1) + omega * v  # [N]
    res_v = (grad_v * F).sum(dim=1) - omega * u  # [N]

    grad_res_u = torch.autograd.grad(res_u.sum(), pts, create_graph=True)[0]  # [N, dim]
    grad_res_v = torch.autograd.grad(res_v.sum(), pts, create_graph=True)[0]  # [N, dim]

    return (grad_res_u**2 + grad_res_v**2).mean()
