# In this current implementation we don't compute the full Floquet spectrum, but only the zeroth Floquet Vectors.
from collections.abc import Callable
from typing import Literal

import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline

type VectorField = Callable[[np.ndarray], np.ndarray]
type JacobianFunc = Callable[[np.ndarray], np.ndarray]
type OdeSolver = Literal["RK45", "DOP853", "BDF", "LSODA", "Radau"]


class FloquetSolver:
    # Default tolerances and evolution cycles for numerical integration
    NUM_ROTATIONS = 30
    DEFAULT_RTOL = 1e-9
    DEFAULT_ATOL = 1e-12

    def __init__(
        self,
        system: VectorField,
        jacobian: JacobianFunc,
        period: float,
        zero_phase_state: np.ndarray,
        num_points: int = 10000,
        num_rotations: int = NUM_ROTATIONS,
        rtol: float = DEFAULT_RTOL,
        atol: float = DEFAULT_ATOL,
        ode_method: OdeSolver = "RK45",
    ) -> None:
        self.system = system
        self.jacobian = jacobian
        self.period = period
        self.omega = 2 * np.pi / period
        self.num_points = num_points
        self.zero_phase_state = zero_phase_state
        self.rtol = rtol
        self.atol = atol
        self.method = ode_method
        self.num_rotations = num_rotations

    def calculate_u0(self, limit_cycle: np.ndarray) -> np.ndarray:
        return np.array([self.system(x) / self.omega for x in limit_cycle])

    def calculate_v0(
        self,
        time_vector: np.ndarray,
        limit_cycle: np.ndarray,
        u0: np.ndarray,
    ) -> np.ndarray:
        limit_cycle_spline = CubicSpline(
            time_vector, limit_cycle, bc_type="periodic", extrapolate="periodic"
        )
        u0_spline = CubicSpline(
            time_vector, u0, bc_type="periodic", extrapolate="periodic"
        )

        dim = len(self.zero_phase_state)

        def adjoint_rhs(t: float, v: np.ndarray) -> np.ndarray:
            x = limit_cycle_spline(self.period - t)
            return (self.jacobian(x).T) @ v

        v_current = np.ones(dim) / np.sqrt(dim)
        for _ in range(self.num_rotations):
            sol = solve_ivp(
                adjoint_rhs,
                (0, self.period),
                v_current,
                method=self.method,
                rtol=self.rtol,
                atol=self.atol,
            )
            v_end = sol.y[:, -1]
            norm = np.dot(v_end, u0_spline(0))
            v_current = v_end / norm

        t_eval = np.linspace(0, self.period, self.num_points, endpoint=True)
        sol = solve_ivp(
            adjoint_rhs,
            (0, self.period),
            v_current,
            method=self.method,
            t_eval=t_eval,
            rtol=self.rtol,
            atol=self.atol,
        )

        vi_vec = sol.y.T
        for i in range(self.num_points):
            norm = np.dot(vi_vec[i], u0_spline(self.period - t_eval[i]))
            vi_vec[i] /= norm
        vi_vec[-1] = vi_vec[0]

        return vi_vec[::-1].copy()
