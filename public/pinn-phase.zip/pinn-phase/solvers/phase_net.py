import numpy as np
import torch
import torch.nn as nn


class PhaseNet(nn.Module):
    r"""
    PINN for the phase function \theta: $R^n$ \to S^1$.

    Outputs $(\cos\Theta, \sin\Theta)$
    Architecture: fully connected, tanh activations.
    Last layer is linear with 2 outputs that we interpret as $(\cos \theta, \sin \theta)$.

    Optional input normalisation (input_mean / input_std) rescales each dimension to
    zero mean / unit variance before the first linear layer.

    This is stored as non-trainable buffers so that autograd and physcics losses are consistent,
    keeping the PDE / adjoint losses valid without any modifications.
    """

    def __init__(
        self,
        hidden_dim: int = 128,
        n_layers: int = 5,
        input_dim: int = 2,
        input_mean: torch.Tensor | None = None,
        input_std: torch.Tensor | None = None,
    ):
        super().__init__()
        layers: list[nn.Module] = [nn.Linear(input_dim, hidden_dim), nn.Tanh()]
        for _ in range(n_layers - 1):
            layers += [nn.Linear(hidden_dim, hidden_dim), nn.Tanh()]
        layers.append(nn.Linear(hidden_dim, 2))  # ($\cos \theta$, $\sin \theta$)
        self.net = nn.Sequential(*layers)

        if input_mean is not None and input_std is not None:
            self.register_buffer("input_mean", input_mean.float())
            self.register_buffer("input_std", input_std.float())
        else:
            self.input_mean = None
            self.input_std = None

    def _normalize(self, x: torch.Tensor) -> torch.Tensor:
        if self.input_mean is not None and self.input_std is not None:
            return (x - self.input_mean) / self.input_std
        return x

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        r"""Returns $(\cos\Theta, \sin\Theta)$ for each input state vector."""
        return self.net(self._normalize(x))

    def phase(self, x: torch.Tensor) -> torch.Tensor:
        r"""Returns phase $\Theta \in [0, 2\pi)$"""
        out = self.forward(x)
        return torch.atan2(out[:, 1], out[:, 0]) % (2 * torch.pi)

    def modulus(self, x: torch.Tensor) -> torch.Tensor:
        r"""Returns modulus $\sqrt{\cos^2\Theta + \sin^2\Theta}$, which should be around to 1."""
        out = self.forward(x)
        return torch.sqrt(out[:, 0] ** 2 + out[:, 1] ** 2)

    def phase_gradient(self, x: torch.Tensor | np.ndarray, device) -> np.ndarray:
        r"""\nabla \Theta(x) Used for inference and control used also for the PSF."""
        x = torch.tensor(x, dtype=torch.float32, device=device).requires_grad_(True)
        out = self.forward(x)
        u_net, v_net = out[:, 0], out[:, 1]
        grad_u = torch.autograd.grad(u_net.sum(), x, retain_graph=True)[0]
        grad_v = torch.autograd.grad(v_net.sum(), x)[0]
        Z = -v_net.unsqueeze(1) * grad_u + u_net.unsqueeze(1) * grad_v
        return Z.detach().cpu().numpy()
