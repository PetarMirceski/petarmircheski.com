from collections.abc import Callable
from typing import Literal

import numpy as np
from scipy.integrate import solve_bvp, solve_ivp

type VectorField = Callable[[np.ndarray], np.ndarray]
type OdeSolver = Literal["RK45", "DOP853", "BDF", "LSODA"]


class PeriodFinder:
    DEFAULT_RTOL = 1e-9
    DEFAULT_ATOL = 1e-12
    DEFAULT_MAX_TIME = 1e3
    BVP_TOL = 1e-10
    BVP_MAX_NODES = 100000
    BVP_NUM_NODES = 10000

    def __init__(
        self,
        system: VectorField,
        threshold_value: float = 0.0,
        state_index: int = 1,
        direction: int = -1,
        max_time: float = DEFAULT_MAX_TIME,
        rtol: float = DEFAULT_RTOL,
        atol: float = DEFAULT_ATOL,
        bvp_tol: float = BVP_TOL,
        bvp_max_nodes: int = BVP_MAX_NODES,
        bvp_num_nodes: int = BVP_NUM_NODES,
        ode_method: OdeSolver = "RK45",
    ) -> None:
        self.system = system
        self.threshold_value = threshold_value
        self.state_index = state_index
        self.direction = direction
        self.max_time = max_time
        self.rtol = rtol
        self.atol = atol
        self.bvp_tol = bvp_tol
        self.bvp_max_nodes = bvp_max_nodes
        self.bvp_num_nodes = bvp_num_nodes
        self.method = ode_method

    def create_crossing_event(self) -> Callable[[float, np.ndarray], float]:
        def event(_: float, y: np.ndarray) -> float:
            return y[self.state_index] - self.threshold_value

        event.terminal = True  # ty: ignore
        event.direction = self.direction  # ty: ignore
        return event

    def find_period(self, initial_state: np.ndarray) -> tuple[float, np.ndarray]:
        event = self.create_crossing_event()

        # First integration: find the first crossing to establish the zero-phase point
        sol1 = solve_ivp(
            lambda _, y: self.system(y),
            (0, self.max_time),
            initial_state,
            method=self.method,
            events=event,
            rtol=self.rtol,
            atol=self.atol,
            dense_output=True,
        )

        if len(sol1.t_events[0]) == 0:
            raise RuntimeError(
                f"No threshold crossing detected within max_time={self.max_time}. "
                "Check that the system has a limit cycle and the threshold is appropriate."
            )

        first_crossing_state = sol1.y_events[0][0]

        # Step slightly past the crossing to avoid re-trigger at t0
        t_skip = max(1e-6, sol1.t_events[0][0] * 1e-4)
        sol_skip = solve_ivp(
            lambda _, y: self.system(y),
            (0, t_skip),
            first_crossing_state,
            method=self.method,
            rtol=self.rtol,
            atol=self.atol,
        )
        stepped_state = sol_skip.y[:, -1]

        # Second integration: find the next crossing to measure the period
        sol2 = solve_ivp(
            lambda _, y: self.system(y),
            (0, self.max_time),
            stepped_state,
            method=self.method,
            events=event,
            rtol=self.rtol,
            atol=self.atol,
            dense_output=True,
        )

        if len(sol2.t_events[0]) == 0:
            raise RuntimeError(
                f"Second threshold crossing not detected within max_time={self.max_time}. "
                "The system may not have a stable limit cycle."
            )

        period = t_skip + sol2.t_events[0][0]
        zero_phase_state = sol2.y_events[0][0]

        return period, zero_phase_state

    def extract_limit_cycle_mesh(
        self,
        zero_phase_state: np.ndarray,
        period: float,
        num_points: int,
    ) -> tuple[np.ndarray, np.ndarray]:
        t_span = np.linspace(0, period, num_points)
        sol = solve_ivp(
            lambda _, y: self.system(y),
            (0, period),
            zero_phase_state,
            t_eval=t_span,
            method=self.method,
            rtol=self.rtol,
            atol=self.atol,
        )
        t_norm = sol.t / period
        return t_norm, sol.y

    def calculate_limit_cycle_with_bvp(
        self,
        zero_phase_state: np.ndarray,
        period: float,
        num_points: int,
        phase_component: int = 1,
    ):
        t_norm, y_mesh = self.extract_limit_cycle_mesh(
            zero_phase_state, period, self.bvp_num_nodes
        )

        def bvp_rhs(_, y, p):
            T = p[0]
            f = np.array([self.system(col) for col in y.T]).T
            return T * f

        phase_anchor = float(zero_phase_state[phase_component])

        def bc(ya, yb, _):
            periodicity = ya - yb
            phase = np.array([ya[phase_component] - phase_anchor])
            return np.concatenate([periodicity, phase])

        result = solve_bvp(
            bvp_rhs,
            bc,
            t_norm,
            y_mesh,
            p=[period],
            tol=self.bvp_tol,
            max_nodes=self.bvp_max_nodes,
            verbose=1,
        )

        if not result.success:
            print(f"Warning solve_bvp did not fully converge: {result.message}")

        T_exact = float(result.p[0])
        t_norm_dense = np.linspace(0, 1, num_points)
        time_vector = t_norm_dense * T_exact
        limit_cycle = result.sol(t_norm_dense).T
        u0 = result.sol.derivative()(t_norm_dense).T / (2 * np.pi)
        limit_cycle[-1] = limit_cycle[0]
        u0[-1] = u0[0]

        return T_exact, time_vector, limit_cycle, u0, result

    def calculate_limit_cycle(
        self,
        period: float,
        zero_phase_state: np.ndarray,
        num_points: int,
    ) -> tuple[np.ndarray, np.ndarray]:
        t_eval = np.linspace(0, period, num_points, endpoint=True)

        sol = solve_ivp(
            lambda _, y: self.system(y),
            (0, period),
            zero_phase_state,
            method=self.method,
            t_eval=t_eval,
            rtol=self.rtol,
            atol=self.atol,
        )

        return sol.t, sol.y.T
