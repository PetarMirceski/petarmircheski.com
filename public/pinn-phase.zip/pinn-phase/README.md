# PINN for the asymptotic phase of limit-cycle oscillators

This repository implements Physics-Informed Neural Networks (PINNs) for learning phase functions of limit cycle oscillators. The 
networks are trained to satisfy the phase equation in state space, not just on the limit cycle, enabling accurate computation of isochrons and phase sensitivity functions validated against Floquet theory.

## Overview

For a dynamical system with a stable limit cycle, the **global phase function** $\Theta(X)$ assigns a phase to every point in the basin of attraction. It satisfies the **phase equation**:

$\nabla \Theta(X) F(X) = \omega$

where $F(X)$ is the vector field and $\omega$ is the natural frequency. 
PINNs enforce this PDE as a physics loss during training, together with boundary conditions on the limit cycle and a constraint that the phase sensitivity ($\nabla \Theta$ on the LC) matches the Floquet adjoint eigenvector.

## Oscillator Systems

| Notebook                                                       | System          |
| -------------------------------------------------------------- | --------------- |
| [pin_stuart_landau_clean.ipynb](pin_stuart_landau_clean.ipynb) | Stuart-Landau   |
| [pin_fhn_clean.ipynb](pin_fhn_clean.ipynb)                     | FitzHugh-Nagumo |
| [pin_rossler_clean_ball.ipynb](pin_rossler_clean_ball.ipynb)   | Rossler         |

## Method

Each notebook follows the same workflow:

1. **Limit cycle computation** - integrate the ODE to convergence and identify the period and zero-phase state
2. **Floquet analysis** - compute the adjoint Floquet eigenvector (phase sensitivity on the LC) via eigenvalue perturbation
3. **Collocation sampling** - build a grid of points in the neighbourhood of the LC
4. **PINN training** - minimise a composite loss:
5. **Optimiser schedule** - 5000 epochs Adam followed by 500 L-BFGS refinement
6. **Validation** - compare PINN phase field against numerical/analytical ground truth, for Stuart-Landau, compare against the exact closed-form solution 
7. **Closed-loop control** - demonstrate phase locking with feedback $u(t) = -K \nabla \Theta \sin(\phi)$

## Network Architecture

All notebooks use the same `PhaseNet`:

- Input: state vector (dim 2 or 3)
- Hidden: 5 layers x 128 units with Tanh activations
- Output (dim 2): scalar phase $u = \cos(\Theta)$ $v = \sin(\Theta)$

## Installation

The project uses [Poetry](https://python-poetry.org/) for dependency management.

```bash
git clone <this-repo>
cd <repo>

# Install dependencies
poetry install

# Activate the virtual environment
poetry shell
```